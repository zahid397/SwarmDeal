// server/src/services/aiService.js

const aiService = {
  async chat(message) {
    // Demo AI response (later OpenAI/Gemini বসাবি)
    return `🤖 Demo AI reply: ${message}`;
  },
};

export default aiService;
